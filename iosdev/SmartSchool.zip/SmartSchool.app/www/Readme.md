測試push message的網頁
http://223.203.192.27:8008/wcttool/smart/msg/compose

ionic plugin add org.apache.cordova.media

这一篇有例子 晚点看
https://blog.nraboy.com/2014/11/playing-audio-android-ios-ionicframework-app/
